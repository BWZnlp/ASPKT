# encoding = utf-8
import torch
import torch.nn.functional as F


class Attn(torch.nn.Module):
    def __init__(self, hidden_size, method='general'):
        super(Attn, self).__init__()
        self.method = method
        if self.method not in ['dot', 'general', 'concat', 'F1']:
            raise ValueError(self.method, "is not an appropriate attention method.")
        self.hidden_size = hidden_size
        if self.method == 'general':
            # target 与 context共用一个hidden_size
            self.attn = torch.nn.Linear(self.hidden_size, hidden_size, bias=False)
        if self.method == 'F1':
            # target 与 context共用一个hidden_size
            self.attn = torch.nn.Linear(self.hidden_size, hidden_size, bias=False)

    def general_score(self, target_vec, context_output):
        energy = self.attn(context_output)
        target_vec = target_vec.unsqueeze(1).repeat(1, context_output.size(1), 1)
        return torch.sum(target_vec * energy, dim=2)

    def layer_score(self, context_output):
        energy = self.attn(context_output)
        return torch.sum(energy, dim=2)

    def forward(self, hidden, encoder_outputs, encoder_outputs_lengths):
        # Calculate the attention weights (energies) based on the given method
        if self.method == 'general':
            attn_energies = self.general_score(hidden, encoder_outputs)

            max_len = attn_energies.size(1)
            idxes = torch.arange(0, max_len, out=torch.LongTensor(max_len)).unsqueeze(0)

            mask = (idxes >= encoder_outputs_lengths.unsqueeze(1)).cuda()
            attn_energies.data.masked_fill_(mask, -float('inf'))
            attentions = F.softmax(attn_energies, dim=1)
            weighted = torch.mul(encoder_outputs, attentions.unsqueeze(-1).expand_as(encoder_outputs))
            representations = weighted.sum(dim=1)
            return representations, attentions
        if self.method == 'F1':
            attn_energies = self.layer_score(encoder_outputs)
            attentions = F.softmax(attn_energies, dim=1)
            weighted = torch.mul(encoder_outputs, attentions.unsqueeze(-1).expand_as(encoder_outputs))
            representations = weighted.sum(dim=1)
            return representations, attentions
