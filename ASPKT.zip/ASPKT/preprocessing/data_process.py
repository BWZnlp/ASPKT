from xml.etree.ElementTree import parse

polarity_map = {
    'neutral': '0',
    'negative': '-1',
    'positive': '1'
}


def parse_sentence_term(path, lowercase=False, store_path='./datasets/MAMS-ATSA/train.raw'):
    tree = parse(path)
    sentences = tree.getroot()
    data = []
    split_char = '\n'
    with open(store_path, 'w')as w:
        for sentence in sentences:
            text = sentence.find('text')
            if text is None:
                continue
            text = text.text
            if lowercase:
                text = text.lower()
            aspectTerms = sentence.find('aspectTerms')
            if aspectTerms is None:
                continue
            for aspectTerm in aspectTerms:
                term = aspectTerm.get('term')
                if lowercase:
                    term = term.lower()
                marked_text = text.replace(term, '$T$')
                polarity = polarity_map[aspectTerm.get('polarity')]
                piece = marked_text + split_char + term + split_char + polarity + split_char
                w.write(piece)
                data.append(piece)
    return data


parse_sentence_term('./datasets/MAMS-ATSA/raw/train.xml', store_path='./datasets/MAMS-ATSA/train.raw')
parse_sentence_term('./datasets/MAMS-ATSA/raw/val.xml', store_path='./datasets/MAMS-ATSA/val.raw')
parse_sentence_term('./datasets/MAMS-ATSA/raw/test.xml', store_path='./datasets/MAMS-ATSA/test.raw')
