from senticnet.senticnet import SenticNet
import networkx as nx
import matplotlib.pyplot as plt
# from senticnet.senticnet import SenticNet
import torch
import os
from tqdm import tqdm
import sys
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import torch.nn as nn
import torch.nn.functional as F
import gensim
import pickle
import os
import sys
import numpy as np
# import joblib
from nltk.corpus import wordnet

basepath = sys.path[0]

sn = SenticNet('en')
G = nx.Graph()

overall_rate = 15  # 目前该参数没有意义

from collections import deque


def compate_word(word_a, word_b, word_ori):
    '''
    比较两个词的分数
    :param word_a:
    :param word_b:
    :param word_ori:
    :return:
    '''
    fre_limit = 5
    rate = 5

    if abs(fre_dict[word_a] - fre_dict[word_b]) > fre_limit:
        return (word_a, fre_dict[word_a]) if fre_dict[word_a] > fre_dict[word_b] else (word_b, fre_dict[word_b])
    else:
        moodtags_ori = sn.moodtags(word_ori)
        moodtags_a = sn.moodtags(word_a)
        moodtags_b = sn.moodtags(word_b)
        score_a = len(set(moodtags_a) & set(moodtags_ori)) / 2 * rate + fre_dict[word_a]
        score_b = len(set(moodtags_b) & set(moodtags_ori)) / 2 * rate + fre_dict[word_b]
        return (word_a, score_a) if score_a > score_b else (word_b, score_b)


def get_max_freq_semantic_by_bfs(cur_word, max_n, ori_word):
    if cur_word not in sn.data.keys():
        return cur_word, 0
    best_word = cur_word
    best_rate = fre_dict[best_word] if best_word in sn.data.keys() else 0
    freq_queue = deque()  # 建立双端队列
    freq_queue += [best_word]
    vis_set = set()  # 建立mark标记，剪枝
    while max_n > 0 and freq_queue:  #
        element = freq_queue.popleft()
        semantics = sn.semantics(element)
        # print(element, semantics)
        for ij in semantics:
            if "_" not in ij and ij not in vis_set:
                freq_queue += [ij]
                (best_word, best_rate) = compate_word(ij, best_word, ori_word)
        max_n -= 1
    print("check", best_word, best_rate)
    return best_word, best_rate


# 构建sn字符集
allword = list(sn.data.keys())
all_word_list = []
for i in range(len(allword)):
    if "_" not in allword[i]:
        allword_i = allword[i]
        all_word_list.append(allword_i)
        semantics = sn.semantics(allword_i)
        for word_ in semantics:
            if "_" not in word_:
                all_word_list.append(word_)

# 字符频繁计数
fre_dict = {}
for key in all_word_list:
    fre_dict[key] = fre_dict.get(key, 0) + 1
fre_dict["NONE"] = 0

# 构建primary_dict
max_iter = 1  # 迭代次数， 跳数
primary_dict = {}
for i in range(len(allword)):
    if '_' not in allword[i]:
        allword_i = allword[i]
        freq_word, freq_rate = get_max_freq_semantic_by_bfs(allword_i, max_iter, allword_i)

        if freq_rate > overall_rate:
            print(allword_i, freq_word, freq_rate)
        primary_dict[allword[i]] = freq_word
print(len(primary_dict))

pickle.dump(primary_dict, open('primary_dict1-bfs_1_version_2', 'wb'), -1)

# 输出统计字典信息
fn = list(primary_dict.values())
fns = set(list(primary_dict.values()))
print(len(fn), len(fns))
