# -*- coding: utf-8 -*-

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.dynamic_rnn import DynamicLSTM


class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, text, adj, prob, idx):
        if idx == True:
            # adj = F.relu(adj+ 0.1 * (prob+prob.transpose(1,2)))
            adj = adj + 0.1 * (prob + prob.transpose(1, 2))
            adj = torch.clamp(adj, min=0, max=100, out=None)
        else:
            adj = adj
        hidden = torch.matmul(text, self.weight)
        denom = torch.sum(adj, dim=2, keepdim=True) + 1
        output = torch.matmul(adj, hidden) / denom
        if self.bias is not None:
            return output + self.bias
        else:
            return output


class ASPKT(nn.Module):
    def __init__(self, embedding_matrix, opt):
        super(ASPKT, self).__init__()
        self.opt = opt
        self.embed = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.hd = opt.hidden_dim
        self.text_L = nn.LSTM(opt.embed_dim, opt.hidden_dim)

        self.text_GRU = nn.GRU(opt.embed_dim, opt.embed_dim)
        self.FWD = nn.Linear(opt.embed_dim, opt.hidden_dim)
        self.FWD_back = nn.Linear(opt.embed_dim, opt.hidden_dim)

        self.gc1 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        self.gc2 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)

        self.fc1 = nn.Linear(2 * opt.hidden_dim, opt.polarities_dim)
        self.text_embed_dropout = nn.Dropout(0.3)

    def resver_tensor(self, input):
        revers_x_ = input
        temp_zero_embed = torch.zeros_like(revers_x_)
        for i_batch in range(0, revers_x_.shape[0]):
            for i_len in range(0, revers_x_.shape[1]):
                temp_zero_embed[i_batch][i_len] = reversed(revers_x_[i_batch][i_len])
        return temp_zero_embed

    def position_weight(self, x, aspect_double_idx, text_len, aspect_len):
        batch_size = x.shape[0]
        seq_len = x.shape[1]
        aspect_double_idx = aspect_double_idx.cpu().numpy()
        text_len = text_len.cpu().numpy()
        aspect_len = aspect_len.cpu().numpy()
        weight = [[] for i in range(batch_size)]
        for i in range(batch_size):
            context_len = text_len[i] - aspect_len[i]
            for j in range(aspect_double_idx[i, 0]):
                weight[i].append(1 - (aspect_double_idx[i, 0] - j) / context_len)
            for j in range(aspect_double_idx[i, 0], aspect_double_idx[i, 1] + 1):
                weight[i].append(0)
            for j in range(aspect_double_idx[i, 1] + 1, text_len[i]):
                weight[i].append(1 - (j - aspect_double_idx[i, 1]) / context_len)
            for j in range(text_len[i], seq_len):
                weight[i].append(0)
        weight = torch.tensor(weight, dtype=torch.float32).unsqueeze(2).to(self.opt.device)
        return weight * x

    def mask(self, x, aspect_double_idx):
        batch_size, seq_len = x.shape[0], x.shape[1]
        aspect_double_idx = aspect_double_idx.cpu().numpy()
        mask = [[] for i in range(batch_size)]
        for i in range(batch_size):
            for j in range(aspect_double_idx[i, 0]):
                mask[i].append(0)
            for j in range(aspect_double_idx[i, 0], aspect_double_idx[i, 1] + 1):
                mask[i].append(1)
            for j in range(aspect_double_idx[i, 1] + 1, seq_len):
                mask[i].append(0)
        mask = torch.tensor(mask).unsqueeze(2).float().to(self.opt.device)
        return mask * x

    def mask_rs(self, x, aspect_double_idx):
        batch_size, seq_len = x.shape[0], x.shape[1]
        aspect_double_idx = aspect_double_idx.cpu().numpy()
        mask = [[] for i in range(batch_size)]
        for i in range(batch_size):
            for j in range(aspect_double_idx[i, 0]):
                mask[i].append(1)
            for j in range(aspect_double_idx[i, 0], aspect_double_idx[i, 1] + 1):
                mask[i].append(0)
            for j in range(aspect_double_idx[i, 1] + 1, seq_len):
                mask[i].append(1)
        mask = torch.tensor(mask).unsqueeze(2).float().to(self.opt.device)
        return mask * x

    def forward(self, inputs):
        text_indices, aspect_indices, left_indices, adj, text_semantics, \
        text_primary, text_super, ts_indices, ts_dependency_graph, \
        loc_semantic_index_list, text_moodtags = inputs

        semantic_ = self.embed(text_primary)
        sem_mean = torch.sum(semantic_, 2)

        text_len = torch.sum(text_indices != 0, dim=-1)
        aspect_len = torch.sum(aspect_indices != 0, dim=-1)
        left_len = torch.sum(left_indices != 0, dim=-1)
        aspect_double_idx = torch.cat([left_len.unsqueeze(1), (left_len + aspect_len - 1).unsqueeze(1)], dim=1)

        text = self.embed(text_indices)
        embs = self.text_embed_dropout(text)
        ###################################
        #
        #     bagin
        #
        ###################################

        embs_REVS = self.resver_tensor(embs)
        ht_0 = torch.zeros(1, embs.shape[0], self.hd).cuda()
        ct_0 = torch.zeros(1, embs.shape[0], self.hd).cuda()

        text_out_list = []
        hidden_forward_list = []
        ext_list = []
        alpha_ = 0.01
        for ing in range(0, embs.shape[1]):
            ht_0_temp = ht_0
            text_out_1, (ht_0, ct_0) = self.text_L(embs[:, ing, :].unsqueeze(0).contiguous(),
                                                   (ht_0, ct_0))
            text_out_ext, ht_0_ext = self.text_GRU(sem_mean[:, ing, :].unsqueeze(0).contiguous(),
                                                   embs[:, ing, :].unsqueeze(0).contiguous())
            ht_0_ext1 = self.FWD(ht_0_ext)

            ht_0 = ht_0 + alpha_ * ht_0_ext1
            hidden_forward_list.append(ht_0)
            ext_list.append(ht_0_ext)
            text_out_list.append(ht_0)
        hidden_forward = torch.cat(hidden_forward_list, 0)
        ext_forward = torch.cat(ext_list, 0).permute(1, 0, 2).contiguous()
        sem_mean_REVS = self.resver_tensor(ext_forward)

        text_out_list_back = []
        ht_0_back = ht_0
        ct_0_back = ct_0
        for ing_rev in range(0, embs.shape[1]):
            ht_0_back_temp = ht_0_back
            text_out_1, (ht_0_back, ct_0_back) = self.text_L(embs_REVS[:, ing_rev, :].unsqueeze(0).contiguous(),
                                                             (ht_0_back, ct_0_back))
            text_out_ext, ht_0_ext = self.text_GRU(sem_mean_REVS[:, ing_rev, :].unsqueeze(0).contiguous(),
                                                   embs_REVS[:, ing_rev, :].unsqueeze(0).contiguous())
            ht_0_ext2 = self.FWD_back(ht_0_ext)
            ht_0_back = ht_0_back + alpha_ * ht_0_ext2
            text_out_list_back.append(ht_0_back)

        text_out = torch.cat(text_out_list, 0)
        text_out_back = torch.cat(text_out_list_back, 0)
        text_out = torch.cat((text_out, text_out_back), 2).permute(1, 0, 2)

        ###################################
        #
        #     end
        #
        ###################################

        text_out_mask = self.mask_rs(text_out, aspect_double_idx)
        text_out_mask_aspect = self.mask(text_out, aspect_double_idx)
        alpha_text_out_mask = torch.matmul(text_out_mask_aspect, text_out_mask.transpose(1, 2))
        x = F.relu(self.gc1(self.position_weight(text_out,
                                                 aspect_double_idx, text_len, aspect_len),
                            adj, alpha_text_out_mask, True))

        x = F.relu(self.gc2(self.position_weight(x,
                                                 aspect_double_idx, text_len, aspect_len),
                            adj, alpha_text_out_mask, True))

        x = self.mask(x, aspect_double_idx)

        alpha_mat = torch.matmul(x, text_out.transpose(1, 2))
        alpha = F.softmax(alpha_mat.sum(1, keepdim=True), dim=2)
        x = torch.matmul(alpha, text_out).squeeze(1)  # batch_size x 2*hidden_dim
        output = self.fc1(x)

        return output
