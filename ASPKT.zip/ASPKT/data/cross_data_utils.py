# -*- coding: utf-8 -*-

import os
import pickle
import numpy as np
from senticnet.senticnet import SenticNet
import torch
from tqdm import tqdm


def load_word_vec(path, word2idx=None):
    fin = open(path, 'r', encoding='utf-8', newline='\n', errors='ignore')
    word_vec = {}
    for line in fin:
        tokens = line.rstrip().split()
        if word2idx is None or tokens[0] in word2idx.keys():
            try:
                word_vec[tokens[0]] = np.asarray(tokens[1:], dtype='float32')
            except:
                continue
    return word_vec


def build_embedding_matrix(word2idx, embed_dim, type):
    embedding_matrix_file_name = '{0}_{1}_embedding_matrix.pkl'.format(str(embed_dim), type)
    embedding_matrix_file_name = os.path.join('embedding', embedding_matrix_file_name)
    if os.path.exists(embedding_matrix_file_name):
        # print('loading embedding_matrix:', embedding_matrix_file_name)
        embedding_matrix = pickle.load(open(embedding_matrix_file_name, 'rb'))
    else:
        print('loading word vectors ...')
        embedding_matrix = np.zeros((len(word2idx), embed_dim))  # idx 0 and 1 are all-zeros
        embedding_matrix[1, :] = np.random.uniform(-1 / np.sqrt(embed_dim), 1 / np.sqrt(embed_dim), (1, embed_dim))
        fname = '/home/ices804/zhangbowen/zhangbowen/KGGCN/glove.6B.100d.txt'
        word_vec = load_word_vec(fname, word2idx=word2idx)
        # print('building embedding_matrix:', embedding_matrix_file_name)
        for word, i in word2idx.items():
            vec = word_vec.get(word)
            if vec is not None:
                # words not found in embedding index will be all-zeros.
                embedding_matrix[i] = vec
        pickle.dump(embedding_matrix, open(embedding_matrix_file_name, 'wb'))
    return embedding_matrix


class Tokenizer(object):
    def __init__(self, word2idx=None):
        if word2idx is None:
            self.word2idx = {}
            self.idx2word = {}
            self.idx = 0
            self.word2idx['<pad>'] = self.idx
            self.idx2word[self.idx] = '<pad>'
            self.idx += 1
            self.word2idx['<unk>'] = self.idx
            self.idx2word[self.idx] = '<unk>'
            self.idx += 1
        else:
            self.word2idx = word2idx
            self.idx2word = {v: k for k, v in word2idx.items()}

    def fit_on_text(self, text):
        text = text.lower()
        words = text.split()
        for word in words:
            if word not in self.word2idx:
                self.word2idx[word] = self.idx
                self.idx2word[self.idx] = word
                self.idx += 1

    def text_to_sequence(self, text, reverse=False):
        text = text.lower()
        words = text.split()
        unknownidx = 1
        sequence = [self.word2idx[w] if w in self.word2idx else unknownidx for w in words]
        if len(sequence) == 0:
            sequence = [0]
        if reverse:
            sequence = sequence[::-1]
        return sequence


sn = SenticNet('en')
sn_data_keys = list(sn.data.keys())
# primary_dict = pickle.load(open('primary_dict1-bfs', 'rb'))
# primary_dict = pickle.load(open('primary_dict1-bfs_1', 'rb'))
primary_dict = pickle.load(open('primary_dict1-bfs_1_version_2', 'rb'))
super_primary_dict = pickle.load(open('super_primary_spacy', 'rb'))


def get_sn_data_keys2():
    '''
    获取在sn和glove交际
    :return:
    '''
    sn_data_keys = set()

    for key in sn.data.keys():
        if "_" not in key:
            sn_data_keys.add(key)
            semantics = sn.semantics(key)
            for word_ in semantics:
                if "_" not in word_:
                    sn_data_keys.add(word_)
    primary_dict_ = set(list(primary_dict.values()))
    sn_data_keys.update(primary_dict_)

    fname = '/home/ices804/zhangbowen/zhangbowen/KGGCN/glove.6B.100d.txt'
    fin = open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
    word_vec = set()
    for line in fin:
        tokens = line.rstrip().split()
        if tokens[0] in sn_data_keys:
            word_vec.add(tokens[0])

    return word_vec


def get_super_primary_word(text_indices, aspect_in_text, word2idx, idx2word):
    '''
    获取同义词
    :param text_indices:
    :param word2idx:
    :param idx2word:
    :return:
    '''
    semantics_filter = lambda x: '_' not in x and x in word2idx
    token_2_id = lambda x: word2idx[x] if x in word2idx else word2idx['<unk>']
    text_semantics = []
    text_moodtags = []
    primary_data_keys = list(super_primary_dict.keys())
    text = ' '.join([idx2word[i] for i in text_indices])
    document = nlp(text)
    seq_len = len(text.split())

    mask = [0] * seq_len
    for token in document:
        if token.i < seq_len:
            for child in token.children:

                if child.i < seq_len:
                    if token.i in aspect_in_text and child.i not in aspect_in_text:
                        mask[child.i] = 1

    # for token in text_indices:
    for token_id in range(len(text_indices)):
        token = text_indices[token_id]
        token_sp = mask[token_id]
        token = idx2word[token]

        if token in primary_data_keys and token_sp != 0:
            # print(1)
            semantics = super_primary_dict[token]
            Asss = []
            Asss.append(semantics)
            semantics = list(filter(semantics_filter, Asss))
            semantics.extend(['<pad>'] * (6 - len(semantics)))
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)
            moodtags = ['<pad>'] * 2
            moodtags = list(map(token_2_id, moodtags))
            text_moodtags.append(moodtags)


        else:
            semantics = ['<pad>'] * 1
            semantics.extend(['<pad>'] * (6 - len(semantics)))
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)

            moodtags = ['<pad>'] * 2
            moodtags = list(map(token_2_id, moodtags))
            text_moodtags.append(moodtags)

    assert len(text_semantics) == len(text_indices)
    return text_semantics, text_moodtags, mask


def get_primary_word(text_indices, word2idx, idx2word):
    '''
    获取同义词
    :param text_indices:
    :param word2idx:
    :param idx2word:
    :return:
    '''
    semantics_filter = lambda x: '_' not in x and x in word2idx
    token_2_id = lambda x: word2idx[x] if x in word2idx else word2idx['<unk>']
    text_semantics = []
    text_moodtags = []
    primary_data_keys = list(primary_dict.keys())
    for token in text_indices:
        token = idx2word[token]
        if token in primary_data_keys:
            # print(1)
            semantics = primary_dict[token]
            Asss = []
            Asss.append(semantics)
            semantics = list(filter(semantics_filter, Asss))
            semantics.extend(['<pad>'] * (6 - len(semantics)))
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)
            moodtags = ['<pad>'] * 2
            # moodtags.extend(['<pad>'] * (2 - len(moodtags)))
            moodtags = list(map(token_2_id, moodtags))
            text_moodtags.append(moodtags)


        else:
            semantics = ['<pad>'] * 1
            semantics.extend(['<pad>'] * (6 - len(semantics)))
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)

            moodtags = ['<pad>'] * 2
            moodtags = list(map(token_2_id, moodtags))
            text_moodtags.append(moodtags)

    assert len(text_semantics) == len(text_indices)
    return text_semantics, text_moodtags


import spacy

from spacy import displacy

nlp = spacy.load('en_core_web_sm')


def get_primary_word_dependency_tree_matrix2(text, padded_text_indices, word2idx, idx2word, max_len):
    '''
    x先对adj填充，后续加入其他词
    :param text:
    :param padded_text_indices: max_len
    :param word2idx:
    :param idx2word:
    :param max_len:
    :return:
    '''
    semantics_filter = lambda x: '_' not in x and x in word2idx
    token_2_id = lambda x: word2idx[x] if x in word2idx else word2idx['<unk>']

    primary_data_keys = list(primary_dict.keys())

    loc_semantic_index_dict = {}
    loc_semantic_index_list = []
    text_semantic_indices = padded_text_indices.copy()  # 原文+padding
    semantic_indices = []
    for i, token in enumerate(padded_text_indices):
        if token == 0:  # padding
            break
        token = idx2word[token]
        if token in primary_data_keys and semantics_filter(primary_dict[token]):
            semantics_word = primary_dict[token]
            # if semantics_filter(semantics_word):
            loc_semantic_index_dict[semantics_word] = len(text_semantic_indices)
            loc_semantic_index_list.append(i)  # 位置映射
            text_semantic_indices.append(token_2_id(semantics_word))
            semantic_indices.append(token_2_id(semantics_word))
        else:
            loc_semantic_index_list.append(999)  # 位置标记，设置为999，代表pos weight =0
            text_semantic_indices.append(0)
            semantic_indices.append(0)  # 填充Pad

    matrix = np.zeros((len(text_semantic_indices), len(text_semantic_indices))).astype('float32')

    document = nlp(text)
    seq_len = len(text.split())
    # assert seq_len == len(padded_text_indices)

    mask = [0] * seq_len
    for token in document:
        if token.i < seq_len:
            matrix[token.i][token.i] = 1  # 依存树节点 self loop
            for child in token.children:
                if child.i < seq_len:
                    # 对同义词做中间节点
                    if child.text in primary_dict:
                        child_semantics_word = primary_dict[child.text]
                        if child_semantics_word in loc_semantic_index_dict:  # 这里沿用filter函数还是会报错，估计还有携程
                            sem_index = loc_semantic_index_dict[child_semantics_word]
                            # child和同义词
                            matrix[child.i][sem_index] = 1
                            matrix[sem_index][child.i] = 1
                            # 同义词到依赖词
                            matrix[token.i][sem_index] = 1
                            matrix[sem_index][token.i] = 1

                    matrix[token.i][child.i] = 1
                    matrix[child.i][token.i] = 1
    for i in range(max_len, len(text_semantic_indices)):
        matrix[i][i] = 1  # 同义词自环
    return matrix, semantic_indices, text_semantic_indices, loc_semantic_index_list


def norm_lise(a, n):
    s = 0.00001
    b = []
    for i in a:
        s += i

    for j in a:
        b.append(np.float32(j / s))

    for ix in range(int(n - len(b))):
        b.append(np.float32(0))
    return b


def get_primary_word_dependency_tree_matrix(text_raw, text_indices, text_len, word2idx, idx2word):
    semantics_filter = lambda x: '_' not in x and x in word2idx
    token_2_id = lambda x: word2idx[x] if x in word2idx else word2idx['<unk>']

    primary_data_keys = list(primary_dict.keys())

    document = nlp(text_raw)
    seq_len = len(text_raw.split())
    assert seq_len == text_len

    text_semantic_indices = text_indices.copy()
    loc_semantic_index_dict = {}
    semantic_indices = []
    for token in text_indices[:text_len]:
        token = idx2word[token]
        if token in primary_data_keys:
            semantics_word = primary_dict[token]
            if semantics_filter(semantics_word):
                loc_semantic_index_dict[semantics_word] = len(text_semantic_indices)
                text_semantic_indices.append(token_2_id(semantics_word))
                semantic_indices.append(token_2_id(semantics_word))
    matrix = np.zeros((len(text_semantic_indices), len(text_semantic_indices))).astype('float32')

    # 语法树
    for token in document:
        if token.i < seq_len:
            matrix[token.i][token.i] = 1
            for child in token.children:
                if child.i < seq_len:
                    # 对同义词做处理
                    if child in primary_dict:
                        sem_index = loc_semantic_index_dict[primary_dict[child]]
                        # child和同义词
                        matrix[child.i][sem_index] = 1
                        matrix[sem_index][child.i] = 1
                        # 同义词到依赖词
                        matrix[token.i][sem_index] = 1
                        matrix[sem_index][token.i] = 1
                    else:
                        matrix[token.i][child.i] = 1
                        matrix[child.i][token.i] = 1
    for i in range(text_len, len(text_semantic_indices)):
        matrix[i][i] = 1
    return matrix, semantic_indices, text_semantic_indices


dict_order = pickle.load(open('/home/ices804/zhangbowen/zhangbowen/KGGCN_NEWGRAPH/dict_order', 'rb'))


def get_semantics_word(text_indices, word2idx, idx2word):
    '''
    获取同义词
    :param text_indices:
    :param word2idx:
    :param idx2word:
    :return:
    '''
    semantics_filter = lambda x: '_' not in x and x in word2idx
    token_2_id = lambda x: word2idx[x] if x in word2idx else word2idx['<unk>']
    text_semantics = []
    text_moodtags = []
    for token in text_indices:
        token = idx2word[token]
        moodtags = []
        if token in sn_data_keys:
            semantics = sn.semantics(token)
            semantics = list(filter(semantics_filter, semantics))
            for wor in semantics:
                wor_order = dict_order[wor]
                moodtags.append(wor_order)
            semantics.extend(['<pad>'] * (6 - len(semantics)))

            moodtags = norm_lise(moodtags, 6)
            assert len(semantics) == 6
            assert len(moodtags) == 6
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)
            text_moodtags.append(moodtags)
        else:
            semantics = ['<pad>'] * 6
            moodtags = [0] * 6
            semantics = list(map(token_2_id, semantics))
            text_semantics.append(semantics)
            text_moodtags.append(moodtags)
    assert len(text_semantics) == len(text_indices)
    return text_semantics, text_moodtags


class ABSADataset(object):
    def __init__(self, data):
        self.data = data

    def __getitem__(self, index):
        return self.data[index]

    def __len__(self):
        return len(self.data)


class ABSADatesetReader:
    @staticmethod
    def __sematic__(text_indices):
        pass

    @staticmethod
    def __read_text__(fnames):
        text = ''
        for fname in fnames:
            fin = open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
            lines = fin.readlines()
            fin.close()
            for i in range(0, len(lines), 3):
                text_left, _, text_right = [s.lower().strip() for s in lines[i].partition("$T$")]
                aspect = lines[i + 1].lower().strip()
                text_raw = text_left + " " + aspect + " " + text_right
                text += text_raw + " "
        return text

    @staticmethod
    def __read_data__(fname, tokenizer, word2idx, idx2word, max_len):
        fin = open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
        lines = fin.readlines()
        fin.close()
        fin = open(fname + '.graph', 'rb')
        idx2gragh = pickle.load(fin)
        fin.close()

        all_data = []
        for i in tqdm(range(0, len(lines), 3)):
            text_left, _, text_right = [s.lower().strip() for s in lines[i].partition("$T$")]
            aspect = lines[i + 1].lower().strip()
            polarity = lines[i + 2].strip()
            text_raw = text_left + " " + aspect + " " + text_right
            text_indices = tokenizer.text_to_sequence(text_left + " " + aspect + " " + text_right)
            context_indices = tokenizer.text_to_sequence(text_left + " " + text_right)
            text_left_indices = tokenizer.text_to_sequence(text_left)
            text_left_with_aspect_indices = tokenizer.text_to_sequence(text_left + " " + aspect)
            text_right_indices = tokenizer.text_to_sequence(text_right, reverse=True)
            text_right_with_aspect_indices = tokenizer.text_to_sequence(" " + aspect + " " + text_right, reverse=True)
            aspect_indices = tokenizer.text_to_sequence(aspect)
            left_context_len = np.sum(text_left_indices != 0)
            left_context_l = len(text_left_indices)
            aspect_l = len(aspect_indices)
            aspect_len = np.sum(text_left_indices != 0)

            aspect_in_text = [left_context_len.item(), (left_context_len + aspect_len - 1).item()]
            aspect_span = [left_context_l, left_context_l + aspect_l - 1]
            polarity = int(polarity) + 1

            text_semantics, text_moodtags = get_semantics_word(text_indices, word2idx=word2idx, idx2word=idx2word)

            text_super, _, mask_ = get_super_primary_word(text_indices, aspect_span, word2idx=word2idx,
                                                          idx2word=idx2word)

            text_primary, _ = get_primary_word(text_indices, word2idx=word2idx, idx2word=idx2word)
            dependency_graph = idx2gragh[i]

            data = {
                'id': i,
                'text_indices': text_indices,
                'context_indices': context_indices,
                'left_indices': text_left_indices,
                'text_left_with_aspect_indices': text_left_with_aspect_indices,
                'right_indices': text_right_indices,
                'text_right_with_aspect_indices': text_right_with_aspect_indices,
                'aspect_indices': aspect_indices,
                'aspect_in_text': aspect_in_text,
                'polarity': polarity,
                'dependency_graph': dependency_graph,
                'text_semantics': text_semantics,
                'text_primary': text_primary,
                'text_moodtags': text_moodtags,
                'text_super': text_super,
                'text_raw': text_raw
            }

            all_data.append(data)
        return all_data

    def __init__(self, dataset='twitter', embed_dim=300, cross=False, max_len=70):
        print("preparing {0} dataset ...".format(dataset))
        print("preparing {0} dataset ...".format(dataset))
        fname = {
            'twitter': {
                'train': './datasets/acl-14-short-data/train.raw',
                'test': './datasets/acl-14-short-data/test.raw',
                'cross_test': './datasets/acl-14-short-data/cross_test.raw'
            },
            'rest14': {
                'train': './datasets/semeval14/restaurant_train.raw',
                'test': './datasets/semeval14/restaurant_test.raw',
                'cross_test': './datasets/semeval14/restaurant_cross_test.raw'
            },
            'lap14': {
                'train': './datasets/semeval14/laptop_train.raw',
                'test': './datasets/semeval14/laptop_test.raw',
                'cross_test': './datasets/semeval14/laptop_cross_test.raw'
            },
            'two': {
                'train': './datasets/two/two_train.raw',
                'test': './datasets/two/two_test.raw'
            },
            'rest15': {
                'train': './datasets/semeval15/restaurant_train.raw',
                'test': './datasets/semeval15/restaurant_test.raw'
            },
            'rest16': {
                'train': './datasets/semeval16/restaurant_train.raw',
                'test': './datasets/semeval16/restaurant_test.raw'
            },
            'mams': {
                'train': './datasets/MAMS-ATSA/train.raw',
                'test': './datasets/MAMS-ATSA/test.raw',
                'dev': './datasets/MAMS-ATSA/dev.raw',
            },

        }
        # prepare cross-domain embedding
        datasets = ['twitter', 'rest14', 'lap14']
        cross_dataset = 'cross'
        print('preparing cross-domain text...')

        primary_dict_ = " ".join(set(list(get_sn_data_keys2())))

        text = primary_dict_ + " "
        for dataset_ in datasets:
            text = text + ABSADatesetReader.__read_text__(
                [fname[dataset_]['train'], fname[dataset_]['test'], fname[dataset_]['cross_test']])
        word2idx_path = os.path.join('embedding', cross_dataset + '_word2idxa.pkl')
        if os.path.exists(word2idx_path):
            print("loading {0} tokenizer...".format(cross_dataset))
            with open(word2idx_path, 'rb') as f:
                word2idx = pickle.load(f)
                tokenizer = Tokenizer(word2idx=word2idx)
        else:
            tokenizer = Tokenizer()
            tokenizer.fit_on_text(text)
            with open(word2idx_path, 'wb') as f:
                pickle.dump(tokenizer.word2idx, f)

        idx2word = {v: k for k, v in word2idx.items()}
        self.embedding_matrix = build_embedding_matrix(tokenizer.word2idx, embed_dim, cross_dataset)

        if not cross:

            train_data = ABSADatesetReader.__read_data__(fname[dataset]['train'], tokenizer, word2idx=word2idx,
                                                         max_len=max_len,
                                                         idx2word=idx2word)
            percent = 0.8
            sample_num = int(percent * len(train_data))
            self.train_data = ABSADataset(train_data)
            self.test_data = ABSADataset(
                ABSADatesetReader.__read_data__(fname[dataset]['test'], tokenizer, word2idx=word2idx, max_len=max_len,
                                                idx2word=idx2word))
        else:
            self.cross_test_data = ABSADataset(
                ABSADatesetReader.__read_data__(fname[dataset]['cross_test'], tokenizer, word2idx=word2idx,
                                                max_len=max_len,
                                                idx2word=idx2word))
        self.word2idx = word2idx
        self.idx2word = idx2word

