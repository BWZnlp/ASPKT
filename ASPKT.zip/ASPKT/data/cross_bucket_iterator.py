# -*- coding: utf-8 -*-

import math
import random
import torch
import numpy
import spacy
from data.cross_data_utils import get_primary_word_dependency_tree_matrix2


class BucketIterator(object):
    def __init__(self, data, batch_size, sort_key='text_indices', shuffle=True, sort=True, max_len=70, word2id=None,
                 id2word=None):
        self.shuffle = shuffle
        self.max_len = max_len
        self.sort = sort
        self.sort_key = sort_key
        self.word2idx = word2id
        self.idx2word = id2word
        self.batches = self.sort_and_pad(data, batch_size)
        self.batch_len = len(self.batches)

    def sort_and_pad(self, data, batch_size):
        num_batch = int(math.ceil(len(data) / batch_size))
        if self.sort:
            sorted_data = sorted(data, key=lambda x: len(x[self.sort_key]))
        else:
            sorted_data = data
        batches = []
        for i in range(num_batch):
            batches.append(self.pad_data(
                sorted_data[i * batch_size: (i + 1) * batch_size]))
        return batches

    def pad_data(self, batch_data):
        batch_ids = []
        batch_text_indices = []
        batch_context_indices = []
        batch_aspect_indices = []
        batch_left_indices = []
        batch_text_left_with_aspect_indices = []
        batch_right_indices = []
        batch_text_right_with_aspect_indices = []
        batch_polarity = []
        batch_dependency_graph = []
        batch_aspect_in_text = []
        batch_text_semantics = []
        batch_text_primary = []
        batch_text_moodtags = []
        batch_text_super = []
        batch_ts_dependency_graph = []
        batch_ts_indices = []
        batch_loc_semantic_index_list = []
        max_len = max([len(t['text_indices']) for t in batch_data])
        for item in batch_data:
            ids, text_indices, context_indices, left_indices, text_left_with_aspect_indices, \
            right_indices, text_right_with_aspect_indices, aspect_indices, aspect_in_text, \
            polarity, dependency_graph, text_semantics, text_moodtags, text_primary, text_super, \
            text_raw = \
                item['id'], item['text_indices'], item['context_indices'], \
                item['left_indices'], item['text_left_with_aspect_indices'], \
                item['right_indices'], item['text_right_with_aspect_indices'], \
                item['aspect_indices'], item['aspect_in_text'], item['polarity'], item['dependency_graph'], \
                item['text_semantics'], item['text_moodtags'], item['text_primary'], item['text_super'], \
                item['text_raw']
            # print(len(text_indices))
            batch_ids.append(ids)
            text_padding = [0] * (max_len - len(text_indices))
            context_padding = [0] * (max_len - len(context_indices))
            aspect_padding = [0] * (max_len - len(aspect_indices))
            left_padding = [0] * (max_len - len(left_indices))
            text_left_with_aspect_indices_padding = [0] * (max_len - len(text_left_with_aspect_indices))
            right_padding = [0] * (max_len - len(right_indices))
            text_right_with_aspect_indices_padding = [0] * (max_len - len(text_right_with_aspect_indices))
            batch_text_indices.append(text_indices + text_padding)
            batch_context_indices.append(context_indices + context_padding)
            batch_aspect_indices.append(aspect_indices + aspect_padding)
            batch_left_indices.append(left_indices + left_padding)
            batch_text_left_with_aspect_indices.append(
                text_left_with_aspect_indices + text_left_with_aspect_indices_padding)
            batch_right_indices.append(right_indices + right_padding)
            batch_text_right_with_aspect_indices.append(
                text_right_with_aspect_indices + text_right_with_aspect_indices_padding)
            batch_aspect_in_text.append(aspect_in_text)

            batch_polarity.append(polarity)
            batch_text_semantics.append(numpy.pad(text_semantics,
                                                  ((0, max_len - len(text_semantics)),
                                                   (0, 0)),
                                                  'constant'))

            batch_text_primary.append(numpy.pad(text_primary,
                                                ((0, max_len - len(text_primary)),
                                                 (0, 0)), 'constant'))
            batch_text_super.append(numpy.pad(text_super,
                                              ((0, max_len - len(text_super)),
                                               (0, 0)), 'constant'))

            batch_text_moodtags.append(numpy.pad(text_moodtags,
                                                 ((0, max_len - len(text_moodtags)),
                                                  (0, 0)), 'constant'))

            batch_dependency_graph.append(numpy.pad(dependency_graph, \
                                                    (
                                                        (0, max_len - len(text_indices)),
                                                        (0, max_len - len(text_indices))),
                                                    'constant'))

            adj, semantic_indices, text_semantic_indices, loc_semantic_index_list = \
                get_primary_word_dependency_tree_matrix2(text_raw,
                                                         text_indices + text_padding,
                                                         self.word2idx,
                                                         self.idx2word,
                                                         max_len)
            loc_semantic_index_list = loc_semantic_index_list + [999] * (max_len - len(semantic_indices))
            semantic_indices = semantic_indices + [0] * (max_len - len(semantic_indices))
            batch_ts_dependency_graph.append(numpy.pad(adj, \
                                                       (
                                                           (0, 2 * max_len - len(text_semantic_indices)),
                                                           (0, 2 * max_len - len(text_semantic_indices))),
                                                       'constant'))
            batch_ts_indices.append(semantic_indices)
            batch_loc_semantic_index_list.append(loc_semantic_index_list)

        return {
            'id': torch.tensor(batch_ids),
            'text_indices': torch.tensor(batch_text_indices),
            'context_indices': torch.tensor(batch_context_indices),
            'left_indices': torch.tensor(batch_left_indices),
            'text_left_with_aspect_indices': torch.tensor(batch_text_left_with_aspect_indices),
            'right_indices': torch.tensor(batch_right_indices),
            'text_right_with_aspect_indices': torch.tensor(batch_text_right_with_aspect_indices),
            'aspect_indices': torch.tensor(batch_aspect_indices),
            'aspect_in_text': torch.tensor(batch_aspect_in_text),
            'polarity': torch.tensor(batch_polarity),
            'dependency_graph': torch.tensor(batch_dependency_graph),
            'text_semantics': torch.tensor(batch_text_semantics),
            'text_primary': torch.tensor(batch_text_primary),
            'text_moodtags': torch.tensor(batch_text_moodtags),
            'text_super': torch.tensor(batch_text_super),
            'ts_indices': torch.tensor(batch_ts_indices),
            'ts_dependency_graph': torch.tensor(batch_ts_dependency_graph),
            'loc_semantic_index_list': torch.tensor(batch_loc_semantic_index_list),
        }

    def __iter__(self):
        if self.shuffle:
            random.shuffle(self.batches)
        for idx in range(self.batch_len):
            yield self.batches[idx]
